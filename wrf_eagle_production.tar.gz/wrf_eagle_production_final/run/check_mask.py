from netCDF4 import Dataset
import numpy as np

ncfile = Dataset("wrfinput_d01")
#ncfile = Dataset("wrfinput_d02")
land   = ncfile.variables["LANDMASK"][:]
lake   = ncfile.variables["LAKEMASK"][:]

for j in range(land.shape[1]):
    for i in range(land.shape[2]):
        if(land[0,j,i] == 1 and lake[0,j,i] == 1):
            print(i,j)

#!/bin/bash

#....................................................#
#.. This script creates wrfinput for one year,       #
#.. divided into 30 day increments                   # 

#........... Writen by Anders Jensen ................#
#....................................................#
#.. Modified: 29 January 2019

if [[ $# -eq 0 ]] ; then
    echo './run_real.sh YYYY'
    exit 0
fi

#.. Divide each year into 30 day intervals. 
#.. Leap years are ignored

#.. Each run starts on December 18 and lasts 379 days
noleap="2008"
ybegin=$(($1-1))
begin="December 18, "$noleap
begin2="December 18, "$ybegin

dy=$(($1-1-noleap))
dy2=$(($1))

beginYYYY=$(date --date="$begin2" '+%Y')
beginMM=$(date --date="$begin" '+%m')
beginDD=$(date --date="$begin" '+%d')

end=$(date --date="$begin +379 days")
endYYYY=$(date --date="$begin +379 days" '+%Y')
endMM=$(date --date="$begin +379 days" '+%m')
endDD=$(date --date="$begin +379 days" '+%d')

begin_s=$(date --date="$begin" '+%s')
end_s=$(date --date="$begin + 379 days" '+%s')

s_s=$begin_s
current=$begin
count=0
count_out=$count
count_length=${#count}  
if [ $count_length -lt 2 ]; then
    count_out="0"$count
fi

echo "Creating WRF input for "$dy2
count=0
while [ $s_s -lt $end_s ]
do
    old=$(date --date="$current")
    new=$(date --date="$current +30 days")
    s_s=$(date --date="$new" '+%s')
    current=$new
    
    if [ $s_s -gt $end_s ]
    then
	current=$end
    fi
    currYYYY=$(date --date="$current" '+%Y')
    currMM=$(date --date="$current" '+%m')
    currDD=$(date --date="$current" '+%d')

    oldYYYY=$(date --date="$old" '+%Y')
    oldMM=$(date --date="$old" '+%m')
    oldDD=$(date --date="$old" '+%d')

    count_out=$count
    count_length=${#count}  
    if [ $count_length -lt 2 ]; then
	count_out="0"$count
    fi

    #.. Export variables to the submission script
    #.. cheyenne_real_submit
    export BEGIN_YEAR=$dy2            #.. Year (same as from ./run_wrf.sh YYYY)
    export RUN_COUNT=$count_out       #.. Directory count (00 - 12)
    export RUN_COUNT_INT=$count       #.. Directory integer (0 - 12)
    export RUN_OLD_Y=$((oldYYYY+dy))  #.. Beginning year for 30 day period 
    export RUN_OLD_M=$oldMM           #.. Beginning month for 30 day period 
    export RUN_OLD_D=$oldDD           #.. Beginning day for 30 day period 
    export RUN_NEW_Y=$((currYYYY+dy)) #.. End year for 30 day period 
    export RUN_NEW_M=$currMM          #.. End month for 30 day period 
    export RUN_NEW_D=$currDD          #.. End day for 30 day period 

    #.. Run the submission script
    qsub -V cheyenne_real_submit

    count=$((count+1))
done





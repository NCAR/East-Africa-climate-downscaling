#!/bin/bash

#....................................................#
#.. This script sets up and runs WRF for a 30 day
#.. period

#........... Writen by Anders Jensen ................#
#....................................................#

if [[ $# -eq 0 ]] ; then
    echo './run_wrf.sh YYYY'
    exit 0
fi

noleap="2008"
ybegin=$(($1-1))
begin="December 18, "$noleap
begin2="December 18, "$ybegin

dy=$(($1-1-noleap))
dy2=$(($1))

beginYYYY=$(date --date="$begin2" '+%Y')
beginMM=$(date --date="$begin" '+%m')
beginDD=$(date --date="$begin" '+%d')

end=$(date --date="$begin +379 days")
endYYYY=$(date --date="$begin +379 days" '+%Y')
endMM=$(date --date="$begin +379 days" '+%m')
endDD=$(date --date="$begin +379 days" '+%d')

begin_s=$(date --date="$begin" '+%s')
end_s=$(date --date="$begin + 379 days" '+%s')

s_s=$begin_s
current=$begin
count=0
count_out=$count
count_length=${#count}  
if [ $count_length -lt 2 ]; then
    count_out="0"$count
fi

rsl_file="wrf_complete_file"   
rsl_file2="rsl.out.0000"              #.. rsl file
wrf_done="SUCCESS\sCOMPLETE\sWRF"     #.. Printed when wrf completes

count=0
lastrundir="00"
restart="false"
while [ $s_s -lt $end_s ]
do
    old=$(date --date="$current")
    new=$(date --date="$current +30 days")
    s_s=$(date --date="$new" '+%s')
    current=$new
    
    if [ $s_s -gt $end_s ]
    then
	current=$end
    fi
    currYYYY=$(date --date="$current" '+%Y')
    currMM=$(date --date="$current" '+%m')
    currDD=$(date --date="$current" '+%d')

    oldYYYY=$(date --date="$old" '+%Y')
    oldMM=$(date --date="$old" '+%m')
    oldDD=$(date --date="$old" '+%d')

    count_out=$count
    count2=$((count-1))
    count_length=${#count}  
    count_length2=${#count2}  
    if [ $count_length -lt 2 ]; then
	count_out="0"$count
    fi
    if [ $count_length2 -lt 2 ]; then
	count_out2="0"$count2
    fi

    #.. Serach for WRF completion in the rsl file or wrf_complete_file
    rsldir="/glade/scratch/"$USER"/eagle_production/WRFV3/"$((dy2))"/"$count_out"/"$rsl_file
    rsldir2="/glade/scratch/"$USER"/eagle_production/WRFV3/"$((dy2))"/"$count_out"/"$rsl_file2
    exit_loop=0
    if [ -f $rsldir ]; then
	grep -q $wrf_done $rsldir && exit_loop=1
    fi
    if [ -f $rsldir2 ]; then
	grep -q $wrf_done $rsldir2 && exit_loop=1
    fi

    #.. WRF is DONE!!!
    if [[ $count -eq 12 && $exit_loop -eq 1 ]]; then
	echo "WRF complete for "$dy2
	echo "Take a break, go on a hike, drink some coffee!"
	exit 0
    fi

    #.. For start of simulation 
    if [[ $count -eq 0 && $exit_loop -eq 0 ]]; then

	echo "No rsl.out.0000 file found in directory /glade/scratch/"$USER"/eagle_production/WRFV3/"$((dy2))"/"$count_out
        echo "One year of WRF simulations set to begin for "$((dy2))
	restart="false"
	
	export BEGIN_YEAR=$dy2
	export RUN_RESTART=$restart
	export RUN_COUNT=$count_out
	export RUN_COUNT_INT=$count
	export RUN_OLD_Y=$((oldYYYY+dy))
	export RUN_OLD_M=$oldMM
	export RUN_OLD_D=$oldDD
	export RUN_NEW_Y=$((currYYYY+dy))
	export RUN_NEW_M=$currMM
	export RUN_NEW_D=$currDD
	
	#.. submit to cheyenne
	qsub -V cheyenne_wrf_submit
	break
    fi

    if [ $exit_loop -eq 1 ]; then
	#.. If WRF COMPLETE file is found, keep searching
	echo "Searching for correct WRF restart time in directory "$count_out"..."
    else
	#.. Pick up where the previous simulation left off
	echo "Found correct WRF restart time. Restarting from directory "$count_out
	echo "WRF will restart beginning on "$oldMM"-"$oldDD"-"$((oldYYYY+dy))

	#.. Kill if partial run completed
	here_we_are="/glade/scratch/"$USER"/eagle_production/WRFV3/"$((dy2))"/"$count_out"/surface_"*
	if ls $here_we_are 1> /dev/null 2>&1; then
	    echo "Looks like the run did not complete correctly. Exiting."
	    exit 1
	fi
	
	read -p "Are you sure you wish to continue [y/n]? " -n 1 -r
	if [[ $REPLY =~ ^[Yy]$ ]]
	then

	    #.. Restart wrf setup
	    restart="true"
	    export BEGIN_YEAR=$dy2
	    export RUN_RESTART=$restart
	    export RUN_COUNT=$count_out
	    export RUN_COUNT_INT=$count
##	    export RUN_COUNT2=$count_out2
	    export RUN_OLD_Y=$((oldYYYY+dy))
	    export RUN_OLD_M=$oldMM
	    export RUN_OLD_D=$oldDD
	    export RUN_NEW_Y=$((currYYYY+dy))
	    export RUN_NEW_M=$currMM
	    export RUN_NEW_D=$currDD
	
	    #.. submit to cheyenne
	    printf "\nWRF restart submitted.\n" 
	    qsub -V cheyenne_wrf_submit
	    break
	else
	    printf "\nYou don't want to run WRF. Exiting.\n\n"
	    exit 1
	fi
    fi
    count=$((count+1))
done




